---
title: Typo International Design Talks Stuff
---

![Typo International](assets/img/work/proj-1/img1.jpg)

TYPO: International Design Talks is an annual event held in Berlin, London, and San Francisco. This promotional project is developed to market the event for the designindustry. The use of patterns, sophisticated color scheme and typography are applied for the print and mobile application.

![Typo International](assets/img/work/proj-1/img2.jpg)
![Typo International](assets/img/work/proj-1/img3.jpg)
![Typo International](assets/img/work/proj-1/img4.jpg)
![Typo International](assets/img/work/proj-1/img5.jpg)