---
title: "Stripes & Co"
---

![Stripes & Co](assets/img/work/proj-8/stripes-co-NickZoutendijk.jpg)