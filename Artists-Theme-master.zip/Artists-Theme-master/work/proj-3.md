---
title: Crispy Icons
---

![Crispy Icons](assets/img/work/proj-3/CrispyIcons-PetrasNargela.jpg)